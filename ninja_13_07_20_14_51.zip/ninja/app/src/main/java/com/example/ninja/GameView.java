package com.example.ninja;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView {
    /**
     * Объект класса GameLoopThread
     */
    private GameThread mThread;

    public int shotX;
    public int shotY;

    /**
     * Переменная запускающая поток рисования
     */
    private boolean running = false;

    private List<Bullet> ball = new ArrayList<Bullet>();
    private Player player;

    Bitmap players;


    ////////////////////////////////////////////

    int touchX;
    int touchY;
    int touchX2;
    int touchY2;

    int joystickX =40;
    int joystickY = 635;
    int joystickWidth = 325;
    int joystickHeight =325;
    int joystickRightWidth = 400;
    int joystickRightHeight =400;



    public float playerX = 400;
    public float playerY = 400;
    float playerSpeed = 5;
    float playerSpeedX = 0;
    float playerSpeedY = 0;
    float backgroundOffsetX=0f;
    float backgroundOffsetY=0f;


    float u;




    byte joystickFlag;

    boolean shoot;
    boolean isPressed;

    Joystick joystickRight;
    Joystick Joystick;


    Matrix playerMatrix;
    Matrix joystickMatrix;
    Matrix backgroundMatrix;
    Matrix joystickRightMatrix;
    Matrix bulletMatrix;


    Bitmap background;
    Bitmap bitmap;
    Bitmap joystick;
    Bitmap bullet;

    Human human;




    boolean shootFlag = false;

    float bulletCounter = 0;

    float bulletX = 0;
    float bulletY = 0;

    float bulletSpeed = 10f;
    float bulletDirection;

    int shootCounter = 0;

    Bullet b;





    //-------------Start of GameThread--------------------------------------------------\\

    public class GameThread extends Thread {


        /**
         * Объект класса
         */
        private GameView view;

        /**
         * Конструктор класса
         */
        public GameThread(GameView view) {
            this.view = view;
        }

        /**
         * Задание состояния потока
         */
        public void setRunning(boolean run) {
            running = run;
        }

        /**
         * Действия, выполняемые в потоке
         */
        @SuppressLint("WrongCall")
        public void run() {
            while (running) {
                Canvas canvas = null;
                try {
                    // подготовка Canvas-а
                    canvas = view.getHolder().lockCanvas();
                    synchronized (view.getHolder()) {
                        // собственно рисование
                        onDraw(canvas);
                    }
                } catch (Exception e) {
                } finally {
                    if (canvas != null) {
                        view.getHolder().unlockCanvasAndPost(canvas);
                    }
                }
            }
        }
    }

    //-------------End of GameThread--------------------------------------------------\\

    public GameView(Context context) {
        super(context);

        mThread = new GameThread(this);

        /*Рисуем все наши объекты и все все все*/
        getHolder().addCallback(new SurfaceHolder.Callback() {
            /*** Уничтожение области рисования */
            public void surfaceDestroyed(SurfaceHolder holder) {
                boolean retry = true;
                mThread.setRunning(false);
                while (retry) {
                    try {
                        // ожидание завершение потока
                        mThread.join();
                        retry = false;
                    } catch (InterruptedException e) {
                    }
                }
            }

            /** Создание области рисования */
            public void surfaceCreated(SurfaceHolder holder) {
                mThread.setRunning(true);
                mThread.start();
            }

            /** Изменение области рисования */
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }
        });

        /*
        players= BitmapFactory.decodeResource(getResources(), R.drawable.player2);
        player= new Player(this, players);
    */

        Joystick = new Joystick(joystickX, joystickY, joystickWidth, joystickHeight);
        joystickRight = new Joystick(1300,joystickY, joystickRightWidth, joystickRightHeight);




        human = new Human();

        backgroundMatrix = new Matrix();
        backgroundMatrix.postScale(1.3f,1.3f);
        background = BitmapFactory.decodeResource(getResources(), R.drawable.backgroundimage);

        joystickMatrix = new Matrix();
        joystickMatrix.postTranslate(joystickX,joystickY);

        joystickRightMatrix = new Matrix();
        joystickRightMatrix.setScale(joystickRightHeight/325f, joystickRightWidth/325f);
        joystickRightMatrix.postTranslate(1300,joystickY);

        bulletMatrix = new Matrix();

        bullet = BitmapFactory.decodeResource(getResources(), R.drawable.bullet);




        joystick = BitmapFactory.decodeResource(getResources(),R.drawable.joystick);
        bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.survivor);





    }


    /**
     * Функция рисующая все спрайты и фон
     */
    protected void onDraw(Canvas canvas) {


        Paint p = new Paint();
        p.setColor(Color.BLUE);
        p.setTextSize(72);
        p.setStrokeWidth(32);


        calculation();



        canvas.drawBitmap(background, backgroundMatrix, null);


        //canvas.drawBitmap(bitmap,playerMatrix, null);
        Joystick.drawJoystick(joystick,joystickMatrix,canvas);
        joystickRight.drawJoystick(joystick, joystickRightMatrix,canvas);
        //canvas.drawBitmap(joystick, joystickMatrix,null);
        human.drawHuman(bitmap, playerMatrix, canvas);



        canvas.drawText(joystickRight.isShooting(touchX, touchY)+"   Shoot: "+shoot+ " Height: "+joystick.getHeight(), 500, 200, p);
        canvas.drawText(joystickFlag+"   bulletDirection: "+bulletDirection+ "  isPressed: "+ isPressed + " s: " , 500, 400, p);
        // canvas.drawLine(263,300,263,1700,p);
        // canvas.drawLine(10,1163,800,1163,p);
        canvas.drawPoint(playerX+ 110, playerY+133, p);


        bulletCounter++;
        if((bulletCounter % 10 == 0)&&shoot)
        {
            shootFlag = true;
            //bulletMatrix.postRotate(45,playerX+bitmap.getWidth()/2, playerY+bitmap.getHeight()/2);

            bulletX=playerX+110;
            bulletY=playerY+133;
            bulletDirection = joystickRight.direction;

        }

        /*
        if(shootFlag)
        {
            //bulletMatrix.setRotate(joystickRight.direction, bulletX, bulletY);
            bulletX+= bulletSpeed*Math.cos(bulletDirection*3.14f/180);
            bulletY+= bulletSpeed*Math.sin(bulletDirection*3.14f/180);
            bulletMatrix.setTranslate(bulletX+backgroundOffsetX, bulletY+backgroundOffsetY);
            bulletMatrix.postRotate(bulletDirection+180, bulletX+backgroundOffsetX, bulletY+backgroundOffsetY);
            canvas.drawBitmap(bullet, bulletMatrix, null);
        }


         */


        if((joystickFlag == 1)&&isPressed&&shoot&&joystickRight.isShooting(touchX2, touchY2)&&joystickRight.isJoystickTouched(touchX2,touchY2))
        {
            shootCounter++;
            if(shootCounter%15==0) {
                Bullet b;

                b = createSprite(R.drawable.bullet);
                b.x = (int) (playerX + backgroundOffsetX + 110);
                b.y = (int) (playerY + backgroundOffsetY + 133);
                ball.add(b);
            }
        }
        if((joystickFlag == 0)&&shoot&&joystickRight.isShooting(touchX, touchY)&&joystickRight.isJoystickTouched(touchX,touchY))
        {
            shootCounter++;
            if(shootCounter%15==0) {
                Bullet b;

                b = createSprite(R.drawable.bullet);
                b.x = (int) (playerX + backgroundOffsetX + 110);
                b.y = (int) (playerY + backgroundOffsetY + 133);
                ball.add(b);
            }
        }



            Iterator<Bullet> j = ball.iterator();

            while (j.hasNext()) {

                    b = j.next();

                if (b.x >= 1000 || b.x <= 1000) {
                    b.onDraw(canvas);
                } else {
                    j.remove();
                }
            }

        canvas.drawBitmap(players, 5, 120, null);


    }

    public Bullet createSprite(int resource) {
        Bitmap bmp = BitmapFactory.decodeResource(getResources(), resource);
        return new Bullet(this, bmp);
    }


    public boolean onTouchEvent(MotionEvent event) {
        //ball.add(new Bullet(bmp));
        // u = joystick.getDirection(touchX,touchY);
/*
        if(joystickRight.isJoystickTouched(touchX,touchY))
        {
            joystickRight.direction = joystickRight.getDirection(touchX, touchY);
        }

*/
        switch (event.getAction()) {



            case MotionEvent.ACTION_MOVE:
                //s=" s: "+touchX+"  "+touchY;

                int pointerCount = event.getPointerCount();
                int pointerIndex;
                int pointerId;

                for (int i = 0; i < pointerCount; i++) {
                    pointerIndex = i;
                    pointerId = event.getPointerId(pointerIndex);

                    if (pointerId == 0)  // первое касание
                    {
                        //testX1 = event.getX(pointerIndex);


                        touchX = (int) event.getX(pointerIndex);
                        touchY = (int) event.getY(pointerIndex);

                        if (Joystick.isJoystickTouched(touchX, touchY)) {
                            joystickFlag = 1;
                            Joystick.direction = Joystick.getDirection(touchX, touchY);
                            u = Joystick.getDirection(touchX, touchY);
                            isPressed = true;

                        }


                        if (joystickRight.isJoystickTouched(touchX, touchY)) {
                            joystickFlag = 0;
                            joystickRight.direction = joystickRight.getDirection(touchX, touchY);
                            shoot = joystickRight.isShooting(touchX, touchY);

                        }


                    }
                    if (pointerId == 1)  // второе касание
                    {
                        //testX2 = event.getX(pointerIndex);

                        touchX2 = (int) event.getX(pointerIndex);
                        touchY2 = (int) event.getY(pointerIndex);

                        if (joystickFlag == 1) {
                            joystickRight.direction = joystickRight.getDirection(touchX2, touchY2);
                            shoot = joystickRight.isShooting(touchX2, touchY2);

                        }

                        if (joystickFlag == 0) {
                            Joystick.direction = Joystick.getDirection(touchX2, touchY2);
                            u = Joystick.getDirection(touchX2, touchY2);
                            isPressed = true;
                        }
                    }
                }
                break;

            case MotionEvent.ACTION_DOWN:
                touchX = (int) event.getX();
                touchY = (int) event.getY();

                break;

            case MotionEvent.ACTION_UP:
                isPressed = false;
                shoot = false;
                break;

            case MotionEvent.ACTION_POINTER_UP:
                isPressed = false;
                shoot = false;
                break;
        }
        return true;
    }

    public void calculation()
    {
        if(isPressed) {
            playerX+= playerSpeed*Math.cos(u*3.14f/180);
            playerY+= playerSpeed*Math.sin(u*3.14f/180);
        }

        playerMatrix = new Matrix();
        playerMatrix.postScale(0.5f, 0.5f);

        playerMatrix.postTranslate(playerX+backgroundOffsetX, playerY+backgroundOffsetY);
        playerMatrix.postRotate(joystickRight.direction, playerX+backgroundOffsetX+ 110, playerY +backgroundOffsetY+133);

        playerSpeedX = Math.abs(playerSpeed * (float) Math.cos(joystickRight.direction));
        playerSpeedY = Math.abs(playerSpeed * (float) Math.sin(joystickRight.direction));

        if ((-backgroundOffsetX - playerX) > -800) {
            backgroundOffsetX += playerSpeed;


            if (backgroundOffsetX > -10) {
                backgroundOffsetX = -10;
            }
        }

        if((-backgroundOffsetX-playerX)<-1000)
        {
            backgroundOffsetX=backgroundOffsetX-playerSpeed;
            if(backgroundOffsetX<-67)
            {
                backgroundOffsetX=-67;
            }
        }

        if((-backgroundOffsetY-playerY)>-400)
        {
            backgroundOffsetY=backgroundOffsetY+playerSpeed;
            if(backgroundOffsetY>-10)
            {
                backgroundOffsetY=-10;
            }
        }

        if((-backgroundOffsetY-playerY)<-440)
        {
            backgroundOffsetY=backgroundOffsetY-playerSpeed;
            if(backgroundOffsetY<-1125)
            {
                backgroundOffsetY=-1125;
            }
        }

        backgroundMatrix.setTranslate(backgroundOffsetX, backgroundOffsetY);   //X:-67  , Y:-1200

    }

}