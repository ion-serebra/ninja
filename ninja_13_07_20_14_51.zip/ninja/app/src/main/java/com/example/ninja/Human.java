package com.example.ninja;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

public class Human {

    public float humanX;
    public float humanY;
    public float humanSpeed;
    public float humanSpeedX;
    public float humanSpeedY;
    public float rotateAngle;
    public Matrix humanMatrix;
    public Bitmap humanBitmap;
    public Canvas canvas;

    public void setRotateAngle(float rotateAngle) {
        this.rotateAngle = rotateAngle;
    }

    public void init()
    {
        humanX=400;
        humanY=400;
        humanSpeed=5;
        rotateAngle = 45;
        //humanBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.survivor);
    }

    public void drawHuman(Bitmap humanBitmap, Matrix humanMatrix, Canvas canvas)
    {
        //humanMatrix.setTranslate(500,500);
        //humanMatrix.setRotate(45);
        canvas.drawBitmap(humanBitmap, humanMatrix, null);
    }




}
